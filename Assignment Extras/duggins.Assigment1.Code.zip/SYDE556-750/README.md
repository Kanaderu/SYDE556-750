# SYDE556/750
# Simulating Neurobiological Systems
# Chris Eliasmith
# Winter 2016
